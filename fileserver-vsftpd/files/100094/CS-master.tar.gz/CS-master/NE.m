function NE=NE(x,xhat)
    NE=norm(x-xhat)/norm(x);
end